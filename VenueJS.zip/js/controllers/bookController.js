/**
 * Created by AlecNing on 3/15/16.
 */
app.controller('bookController', ['$scope', function($scope) {



    var date = new Date();
    var d = date.getDate();
    var m = date.getMonth();
    var y = date.getFullYear();
    var day =date.getDay();


    $scope.uiConfig = {
        calendar:{
            defaultView: 'agendaWeek',
            firstDay : day,
            height: 450,
            editable: true,
            header: {
                left: '',
                center: 'title',
                right: 'today prev,next'
            },
            dayClick: $scope.alertEventOnClick,
            eventDrop: $scope.alertOnDrop,
            eventResize: $scope.alertOnResize
        }

    };

/*
    $scope.eventSources = [$scope.events];
    $scope.events = [
        {
            title: 'training',
            start: new Date(y, m, d, 8),
            end: new Date(y, m, d, 10)
        }
    ];

    */
/*
    for (var i = d; i < d + 7; i++) {
        for (var j = date.getHours(); j < 24; j++) {
            $scope.events.push(
                {
                    type: 'party',
                    title: 'training',
                    start: new Date(y, m, i, j, 0), end: new Date(y, m, i, j + 2, 0), allDay: false
                }
            );
            console.log($scope.events)
        }
    }
*/


    $scope.events = [
        {
            title: 'TEST Event',
            start: new Date(y, m, 1)},
        {
            title: 'Long Event',
            start: new Date(y, m, d - 5),
            end: new Date(y, m, d - 2)},

        {
            title: 'Click for Google',
            start: new Date(y, m, 28),
            end: new Date(y, m, 29),
            url: 'http://google.com/'
        }]


    $scope.myInterval = 3000;
    $scope.slides = [
        {
            image:
                '../../style/images/venue1/venue1pic1.jpg'
        },
        {
            image:
                '../../style/images/venue2/venue2pic1.jpg'
        },
        {
            image:
                '../../style/images/venue3/venue3pic1.jpg'
        }
    ];

    //------new modified march 17 ---//


    //$scope.changeView('agendaWeek', uiCalendarConfig.calendars.myCalendar);






}]);
